import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:wired_express/data/model/response/coupon_model.dart';
import 'package:wired_express/data/model/response/product_model.dart';

class Helpers {
  static String getVariationType(
      Product product, List<dynamic> variationIndex) {
    // Start => Burger Sandwich , variationIndex = [0, 1]

    List<String> _variationList = [];
    for (int index = 0; index < product.choiceOptions!.length; index++) {
      _variationList.add(product
          .choiceOptions![index] // ['cheese' , 'medium']
          .options![variationIndex[
              index]] // RangeError (index): Invalid value: Valid value range is empty: 0
          .replaceAll(' ', ''));
    }

    // print('variationList=> ${_variationList}'); // [ranch, small]  selected value of this product in cart

    String variationType = '';
    bool isFirst = true;
    _variationList.forEach((variation) {
      if (isFirst) {
        variationType = '$variationType$variation';
        isFirst = false;
      } else {
        variationType = '$variationType-$variation';
      }
    });

    // this converts this : [ranch, small] to  'ranch-small'

    // Final result => 'cheese-small'
    return variationType;
  }

  static double applyDiscount(CouponModel coupon, double orderAmount) {
    double? _discount = 0.0;
    if (coupon.minPurchase != null && coupon.minPurchase! < orderAmount) {
      if (coupon.discountType == 'percent') {
        if (coupon.maxDiscount != null) {
          _discount =
              (coupon.discount! * orderAmount / 100) < coupon.maxDiscount!
                  ? (coupon.discount! * orderAmount / 100)
                  : coupon.maxDiscount;
        } else {
          _discount = coupon.discount! * orderAmount / 100;
        }
      } else {
        _discount = coupon.discount;
      }
    } else {
      _discount = 0.0;
    }
    return _discount!;
  }
  static String formatTextWithNum(String text) {
    return text.replaceAllMapped(
      RegExp(r"-?\d+(\.\d+)?"),
          (match) {
        String numberStr = match.group(0)!;
        if (numberStr.endsWith(".00")) {
          return numberStr.split('.')[0];
        } else if (numberStr.endsWith(".0")) {
          return numberStr.split('.')[0];
        } else if (numberStr.contains('.')) {
          double num = double.parse(numberStr);
          return num.toStringAsFixed(2);
        } else {
          return numberStr;
        }
      },
    ).replaceAllMapped(
      RegExp(r"(?:^| )(\w)"),
          (match) => match.group(0)!.toUpperCase(),
    );
  }

  static Color? selectColor(String color) {
    if (color == 'black' || color == 'Black') {
      return Colors.black;
    }
    if (color == 'white' || color == 'White') {
      return Colors.white;
    }
    if (color == 'red' || color == 'Red') {
      return Colors.red;
    }
    if (color == 'green' || color == 'Green') {
      return Colors.green[700];
    }
    if (color == 'grey' || color == 'Grey') {
      return Colors.grey[700];
    }
  }
}
