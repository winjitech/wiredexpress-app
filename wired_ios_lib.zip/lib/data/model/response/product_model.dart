import 'dart:convert';

class ProductModel {
  int? _totalSize;
  String? _limit;
  String? _offset;
  List<Product>? _products;

  ProductModel(
      {int? totalSize,
      String? limit,
      String? offset,
      List<Product>? products}) {
    this._totalSize = totalSize;
    this._limit = limit;
    this._offset = offset;
    this._products = products;
  }

  int? get totalSize => _totalSize;
  String? get limit => _limit;
  String? get offset => _offset;
  List<Product>? get products => _products;

  ProductModel.fromJson(Map<String?, dynamic> json) {
    _totalSize = json['total_size'];
    if (json['limit'] is int?) {
      _limit = json['limit'].toString();
    } else {
      _limit = json['limit'];
    }

    _offset = json['offset'];
    if (json['products'] != null) {
      _products = [];
      json['products']!.forEach((v) {
        _products!.add(new Product.fromJson(v));
      });
    }
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['total_size'] = this._totalSize;
    data['limit'] = this._limit;
    data['offset'] = this._offset;
    if (this._products != null) {
      data['products'] = this._products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Product {
  int? _id;
  String? _name;
  String? _description;
  String? _image;
  double? _price;
  List<Variation>? _variations;

  double? _tax;
  String? _availableTimeStarts;
  String? _availableTimeEnds;
  int? _status;
  String? _createdAt;
  String? _updatedAt;
  List<dynamic>? _attributes;
  List<CategoryId>? _categoryIds;
  List<ChoiceOption>? _choiceOptions;
  double? _discount;
  String? _discountType;
  String? _taxType;
  int? _setMenu;
  List<Rating>? _rating;
  String? _matchedTag;
  String? _availability;

  Product(
      {int? id,
      String? name,
      String? description,
      String? image,
      double? price,
      List<Variation>? variations,
      double? tax,
      String? availableTimeStarts,
      String? availableTimeEnds,
      int? status,
      String? createdAt,
      String? updatedAt,
      List<dynamic>? attributes,
      List<CategoryId>? categoryIds,
      List<ChoiceOption>? choiceOptions,
      double? discount,
      String? discountType,
      String? taxType,
      int? setMenu,
      List<Rating>? rating,
      String? matchedTag,
      String? availability}) {
    this._id = id;
    this._name = name;
    this._description = description;
    this._image = image;
    this._price = price;
    this._variations = variations;
    this._tax = tax;
    this._availableTimeStarts = availableTimeStarts;
    this._availableTimeEnds = availableTimeEnds;
    this._status = status;
    this._createdAt = createdAt;
    this._updatedAt = updatedAt;
    this._attributes = attributes;
    this._categoryIds = categoryIds;
    this._choiceOptions = choiceOptions;
    this._discount = discount;
    this._discountType = discountType;
    this._taxType = taxType;
    this._setMenu = setMenu;
    this._rating = rating;
    this._matchedTag = matchedTag;
    this._availability = availability;
  }

  int? get id => _id;
  String? get name => _name;
  String? get description => _description;
  String? get image => _image;
  double? get price => _price;
  List<Variation>? get variations => _variations;
  double? get tax => _tax;
  String? get availableTimeStarts => _availableTimeStarts;
  String? get availableTimeEnds => _availableTimeEnds;
  int? get status => _status;
  String? get createdAt => _createdAt;
  String? get updatedAt => _updatedAt;
  List<dynamic>? get attributes => _attributes;
  List<CategoryId>? get categoryIds => _categoryIds;
  List<ChoiceOption>? get choiceOptions => _choiceOptions;
  double? get discount => _discount;
  String? get discountType => _discountType;
  String? get taxType => _taxType;
  String? get matchedTag => _matchedTag;
  int? get setMenu => _setMenu;
  List<Rating>? get rating => _rating;
  String? get availability => _availability;

  Product.fromJson(Map<String?, dynamic> json) {
    _id = json['id'];
    _name = json['name'];
    _description = json['description'];
    _image = json['image'];

    _price = (json['price'] as num).toDouble();
    if (json['variations'] != null) {
      _variations = [];
      // List _variationsGet = jsonDecode(json['variations']);
      json['variations']!.forEach((v) {
        _variations!.add(new Variation.fromJson(v));
      });
    }

    _tax = (json['tax'] as num?)?.toDouble() ?? 0.0;
    _availableTimeStarts = json['available_time_starts'];
    _availableTimeEnds = json['available_time_ends'];
    _status = json['status'];
    _createdAt = json['created_at'];
    _updatedAt = json['updated_at'];
    //_attributes = json['attributes'].cast<String?>();
    _attributes = json['attributes'];
    if (json['category_ids'] != null) {
      _categoryIds = [];
      json['category_ids']!.forEach((v) {
        _categoryIds!.add(new CategoryId.fromJson(v));
      });
    }
    if (json['choice_options'] != null) {
      _choiceOptions = [];
      json['choice_options']!.forEach((v) {
        _choiceOptions!.add(new ChoiceOption.fromJson(v));
      });
    }

    _discount = (json['discount'] as num).toDouble();
    _discountType = json['discount_type'];
    _taxType = json['tax_type'];
    _setMenu = json['set_menu'];
    _matchedTag = json['matchedTag'] ?? '';
    _availability = json['availability'];
    if (json['rating'] != null) {
      _rating = [];
      json['rating']!.forEach((v) {
        _rating!.add(new Rating.fromJson(v));
      });
    } else {
      _rating = [];
    }
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['id'] = this._id;
    data['name'] = this._name;
    data['name_ar'] = this._name;
    data['description'] = this._description;
    data['image'] = this._image;
    data['price'] = this._price;
    if (this._variations != null) {
      data['variations'] = this._variations!.map((v) => v.toJson()).toList();
    }

    data['tax'] = this._tax;
    data['available_time_starts'] = this._availableTimeStarts;
    data['available_time_ends'] = this._availableTimeEnds;
    data['status'] = this._status;
    data['created_at'] = this._createdAt;
    data['updated_at'] = this._updatedAt;
    data['attributes'] = this._attributes;
    if (this._categoryIds != null) {
      data['category_ids'] = this._categoryIds!.map((v) => v.toJson()).toList();
    }
    if (this._choiceOptions != null) {
      data['choice_options'] =
          this._choiceOptions!.map((v) => v.toJson()).toList();
    }
    data['discount'] = this._discount;
    data['discount_type'] = this._discountType;
    data['tax_type'] = this._taxType;
    data['set_menu'] = this._setMenu;
    data['matchedTag'] = this._matchedTag ?? '';
    data['availability'] = this._availability;
    if (this._rating != null) {
      data['rating'] = this._rating!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Variation {
  String? _type;
  String? _image;
  double? _price;

  Variation({String? type, double? price}) {
    this._type = type;
    this._image = image;
    this._price = price;
  }

  String? get type => _type;
  String? get image => _image;
  double? get price => _price;

  Variation.fromJson(Map<String?, dynamic> json) {
    _type = json['type'];
    _image = json['image'];
    if (json['price'] != null) {
      _price = (json['price'] as num).toDouble();
    }
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['type'] = this._type;
    data['image'] = this._image;
    data['price'] = this._price;
    return data;
  }
}

class CategoryId {
  String? _id;
  int? _position;

  CategoryId({String? id, int? position}) {
    this._id = id;
    this._position = position;
  }

  String? get id => _id;
  int? get position => _position;

  CategoryId.fromJson(Map<String?, dynamic> json) {
    _id = json['id'];
    _position = json['position'];
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['id'] = this._id;
    data['position'] = this._position;
    return data;
  }
}

class ChoiceOption {
  String? _name;
  String? _title;
  List<dynamic>? _options;

  ChoiceOption({String? name, String? title, List<String>? options}) {
    this._name = name;
    this._title = title;
    this._options = options;
  }

  String? get name => _name;
  String? get title => _title;
  List<dynamic>? get options => _options;

  ChoiceOption.fromJson(Map<String?, dynamic> json) {
    _name = json['name'];
    _title = json['title'];
    _options = json['options'];
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['name'] = this._name;
    data['title'] = this._title;
    data['options'] = this._options;
    return data;
  }
}

class Rating {
  String? _average;
  int? _productId;

  Rating({String? average, int? productId}) {
    this._average = average;
    this._productId = productId;
  }

  String? get average => _average;
  int? get productId => _productId;

  Rating.fromJson(Map<String?, dynamic> json) {
    _average = json['average'];
    _productId = json['product_id'];
  }

  Map<String?, dynamic> toJson() {
    final Map<String?, dynamic> data = new Map<String?, dynamic>();
    data['average'] = this._average;
    data['product_id'] = this._productId;
    return data;
  }
}
