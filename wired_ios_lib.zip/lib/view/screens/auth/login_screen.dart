import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:wired_express/data/helper/email_checker.dart';
import 'package:wired_express/localization/language_constrants.dart';
import 'package:wired_express/provider/auth_provider.dart';
import 'package:wired_express/provider/cart_provider.dart';
import 'package:wired_express/provider/wishlist_provider.dart';
import 'package:wired_express/utill/color_resources.dart';
import 'package:wired_express/view/base/custom_button.dart';
import 'package:wired_express/view/base/custom_snackbar.dart';
import 'package:wired_express/view/base/custom_text_field.dart';
import 'package:wired_express/view/screens/auth/login_with_phone_screen.dart';
import 'package:wired_express/view/screens/auth/signup_screen.dart';
import 'package:wired_express/view/screens/dashboard/dashboard_screen.dart';
import 'package:wired_express/view/screens/forgot_password/forgot_password_screen.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  FocusNode _emailFocus = FocusNode();
  FocusNode _passwordFocus = FocusNode();
  TextEditingController? _emailController;
  TextEditingController? _passwordController;
  GlobalKey<FormState>? _formKeyLogin;

  @override
  void initState() {
    super.initState();
    _formKeyLogin = GlobalKey<FormState>();
    _emailController = TextEditingController();
    _passwordController = TextEditingController();

    _emailController!.text =
        Provider.of<CustomAuthProvider>(context, listen: false)
                .getUserNumber() ??
            '';
    _passwordController!.text =
        Provider.of<CustomAuthProvider>(context, listen: false)
                .getUserPassword() ??
            '';
  }

  @override
  void dispose() {
    _emailController!.dispose();
    _passwordController!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorResources.SCAFFOLD_COLOR,
      // backgroundColor: ColorResources.getScaffoldBackgroundColor(context!),
      // key: _scaffoldKey,

      body: Consumer<CustomAuthProvider>(
        builder: (context, authProvider, child) {
          return Form(
            key: _formKeyLogin,

            child: Stack(
              children: [
                Positioned(
                  top: 0,
                  left: 0,
                  child: Container(
                    // decoration: BoxDecoration(
                    //     color: Colors.grey[700],
                    //     borderRadius: BorderRadius.only(
                    //         bottomRight: Radius.circular(300),
                    //         bottomLeft: Radius.circular(40),
                    //         topRight: Radius.circular(40))),
                    height: 200,
                    width: 160,
                    child: SafeArea(
                      child: Align(
                        alignment: Alignment.topLeft,
                        child: Padding(
                          padding: const EdgeInsets.only(top: 10, left: 15),
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                            },
                            child: Container(
                                decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(50)),
                                child: Padding(
                                  padding: const EdgeInsets.all(14),
                                  child: Icon(
                                    Icons.arrow_back_ios_new_outlined,
                                    color: ColorResources.SCAFFOLD_COLOR,
                                    size: 19,
                                  ),
                                )),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 0,
                  right: 0,
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.grey[700],
                        borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(40),
                            bottomLeft: Radius.circular(300),
                            topRight: Radius.circular(40))),
                    height: 170,
                    width: 160,
                  ),
                ),
                Positioned(
                  top: 160,
                  left: 30,
                  child: Text(
                    "${getTranslated('welcome_back', context)} \n ${getTranslated('login', context)}",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w700),
                  ),
                ),
                Positioned(
                    bottom: 5,
                    right: 0,
                    left: 0,
                    child: Container(
                        height: 600,
                        decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.only(
                                topRight: Radius.circular(30),
                                topLeft: Radius.circular(30))),
                        child: Padding(
                          padding: const EdgeInsets.all(30),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(height: 40),
                              CustomTextField(
                                hintText:
                                    getTranslated('enter_your_email', context),
                                controller: _emailController,
                                focusNode: _emailFocus,
                                nextFocus: _passwordFocus,
                                inputType: TextInputType.text,
                                // capitalization: TextCapitalizationtalization.words,
                              ),
                              SizedBox(
                                height: 20,
                              ),
                              CustomTextField(
                                hintText: getTranslated('password', context),
                                isPassword: true,
                                controller: _passwordController,
                                focusNode: _passwordFocus,
                                isShowSuffixIcon: true,
                              ),
                              SizedBox(
                                height: 5,
                              ),
                              Align(
                                alignment: Alignment.centerLeft,
                                child: TextButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (BuildContext context) =>
                                                  ForgotPasswordScreen()));
                                    },
                                    child: Text(
                                      getTranslated('forgot_password', context),
                                      style: TextStyle(
                                          color: Colors.grey[600],
                                          fontWeight: FontWeight.w500),
                                    )),
                              ),
                              SizedBox(
                                height: 30,
                              ),
                              authProvider.isLoading == true
                                  ? Center(
                                      child: CircularProgressIndicator(
                                          valueColor: AlwaysStoppedAnimation<
                                                  Color>(
                                              ColorResources.SCAFFOLD_COLOR)))
                                  : CustomButton(
                                      text: getTranslated('login', context),
                                      onTap: () async {
                                        FocusScope.of(context).unfocus();
                                        String _email =
                                            _emailController!.text.trim();
                                        String _password =
                                            _passwordController!.text.trim();

                                        if (_email.isEmpty) {
                                          showCustomSnackBar(
                                              getTranslated(
                                                  'enter_email_address',
                                                  context),
                                              context);
                                        } else if (EmailChecker.isNotValid(
                                            _email)) {
                                          showCustomSnackBar(
                                              getTranslated(
                                                  'enter_valid_email', context),
                                              context);
                                        } else if (_password.isEmpty) {
                                          showCustomSnackBar(
                                              getTranslated(
                                                  'enter_password', context),
                                              context);
                                        } else if (_password.length < 6) {
                                          showCustomSnackBar(
                                              getTranslated(
                                                  'password_should_be',
                                                  context),
                                              context);
                                        } else {
                                          authProvider
                                              .login(context, _email, _password)
                                              .then((status) async {
                                            if (status.isSuccess) {
                                              // DateTime _date = DateTime.now().add(const Duration(days: 7));
                                              // var box = Hive.box('myBox');
                                              // box.put('rate_last_datetime', _date);
                                              authProvider.saveUserNumberAndPassword(_email, _password);
                                              // if (authProvider.isActiveRememberMe!) {
                                              //   authProvider.saveUserNumberAndPassword(_email, _password);
                                              // } else {
                                              //   authProvider
                                              //       .clearUserNumberAndPassword();
                                              // }
                                              await Provider.of<CartProvider>(
                                                      context,
                                                      listen: false)
                                                  .initCartListProductIds(
                                                      context);

                                              await Provider.of<
                                                          WishListProvider>(
                                                      context,
                                                      listen: false)
                                                  .initWishListProductIds(
                                                      context);
                                              // final location = await Provider.of<
                                              //         LocationProvider>(context,
                                              //     listen: false);
                                              // await location
                                              //     .initAddressList(context)
                                              //     .then((value) => location
                                              //             .addressList!.isEmpty
                                              //         ? Navigator.push(
                                              //             context,
                                              //             MaterialPageRoute(
                                              //                 builder: (BuildContext?
                                              //                         context) =>
                                              //                     AddNewAddressScreen()))
                                              //         :
                                              //         Navigator.push(
                                              //             context,
                                              //             MaterialPageRoute(
                                              //                 builder: (BuildContext?
                                              //                         context) =>
                                              //                     DashboardScreen(
                                              //                         pageIndex:
                                              //                             0))));

                                              Navigator.push(
                                                  context,
                                                  MaterialPageRoute(
                                                      builder: (BuildContext?
                                                              context) =>
                                                          DashboardScreen(
                                                              pageIndex: 0)));
                                            }
                                          });
                                        }
                                      }),

                              TextButton(
                                  onPressed: () {
                                    FocusScope.of(context).unfocus();
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (BuildContext
                                            context) =>
                                                DashboardScreen(pageIndex: 0)));
                                  },
                                  child: Text(
                                    getTranslated('login_as_guest', context),
                                    style: TextStyle(
                                      //  fontWeight: FontWeight.w700,
                                        fontSize: 17),
                                  )),
                              SizedBox(height: 35),
                              Row(
                                children: [
                                  Expanded(
                                      child: Divider(
                                    thickness: 1,
                                  )),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Text(getTranslated('or', context)),
                                  SizedBox(
                                    width: 15,
                                  ),
                                  Expanded(
                                      child: Divider(
                                    thickness: 1,
                                  )),
                                ],
                              ),
                              SizedBox(height: 5),
                              TextButton(
                                  onPressed: () {
                                    FocusScope.of(context).unfocus();
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                LoginWithPhoneScreen()));
                                  },
                                  child: Row(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(
                                        getTranslated(
                                            'login_with_phone', context),
                                        style: TextStyle(
                                            fontWeight: FontWeight.w500,
                                            fontSize: 16),
                                      ),
                                    ],
                                  )),

                              SizedBox(height: 10),

                              Align(
                                alignment: Alignment.bottomCenter,
                                child: Row(
                                  crossAxisAlignment:
                                  CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text(
                                      getTranslated(
                                          'dont_have_account', context),
                                      style: TextStyle(
                                          fontWeight: FontWeight.w400,
                                          fontSize: 15),
                                    ),
                                    TextButton(
                                        onPressed: () {
                                          FocusScope.of(context).unfocus();
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (BuildContext
                                                  context) =>
                                                      SignUpScreen()));
                                        },
                                        child: Text(
                                          getTranslated('signup', context),
                                          style: TextStyle(
                                              fontWeight: FontWeight.w700,
                                              fontSize: 17),
                                        )),
                                  ],
                                ),
                              ),

                         //     const SizedBox(height: 50)


                            ],
                          ),
                        ))),
              ],
            ),
            //   ),
            // ),
          );
        },
      ),
    );
  }
}
