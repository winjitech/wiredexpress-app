import 'dart:async';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:provider/provider.dart';
import 'package:wired_express/localization/language_constrants.dart';
import 'package:wired_express/provider/auth_provider.dart';
import 'package:wired_express/provider/location_provider.dart';
import 'package:wired_express/provider/order_provider.dart';
import 'package:wired_express/provider/place_order_provider.dart';
import 'package:wired_express/provider/profile_provider.dart';
import 'package:wired_express/provider/splash_provider.dart';
import 'package:wired_express/view/base/custom_snackbar.dart';
import 'package:wired_express/view/screens/categories/categories_screen.dart';
import 'package:wired_express/view/screens/dashboard/dashboard_screen.dart';
import 'package:wired_express/view/screens/menu/widget/sign_out_confirmation_dialog.dart';
import 'package:wired_express/view/screens/support/support_screen.dart';
import 'package:wired_express/view/screens/terms/terms_screen.dart';
import 'package:wired_express/view/screens/track/order_tracking_screen.dart';

class DrawerScreen extends StatefulWidget {
  @override
  _DrawerScreenState createState() => _DrawerScreenState();
}

class _DrawerScreenState extends State<DrawerScreen> {
  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 2), () async {});
  }

  @override
  Widget build(BuildContext context) {
    final userInfo =
        Provider.of<ProfileProvider>(context, listen: false).userInfoModel;
    final address =
        Provider.of<LocationProvider>(context, listen: false).addressList;

    return SafeArea(child:
        Consumer<ProfileProvider>(builder: (context, profileProvider, child) {
      String? id = Provider.of<CustomAuthProvider>(context, listen: false)
          .getUserAddressId();
      print("--------------${id}");

      return Padding(
          padding: const EdgeInsets.all(30),
          child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 45),
                profileProvider.userInfoModel!.image == null
                    ? SizedBox(
                        height: 70,
                        width: 70,
                      )
                    : Container(
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(50),
                            image: DecorationImage(
                                image: NetworkImage(
                                  '${Provider.of<SplashProvider>(context, listen: false).baseUrls!.customerImageUrl}/${profileProvider.userInfoModel!.image}',
                                ),
                                fit: BoxFit.cover)),
                        height: 70,
                        width: 70,
                      ),
                SizedBox(height: 20),

                profileProvider.userInfoModel!.fName!=null && profileProvider.userInfoModel!.lName!=null?
                Text(
                    '${profileProvider.userInfoModel!.fName!} ${profileProvider.userInfoModel!.lName!}' ??
                        '',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontWeight: FontWeight.w500)): const SizedBox(),
                SizedBox(height: 5),

                Consumer<CustomAuthProvider>(
                  builder: (context, custom, child) {
                    try {
                      if (address == null || address.isEmpty) {
                        return SizedBox();
                      }

                      if (id == null || id.isEmpty) {
                        return Text(
                          address[0].address.toString(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        );
                      }

                      var matchedAddress = address.firstWhere(
                        (element) => element.id == int.parse(id),
                      );

                      if (matchedAddress != null) {
                        return Text(
                          matchedAddress.address.toString(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(color: Colors.white, fontSize: 15),
                        );
                      } else {
                        return SizedBox();
                      }
                    } catch (e) {
                      return SizedBox();
                    }
                  },
                ),

                // address == null
                //     ? SizedBox()
                //     : Text(address![0].address.toString(),
                //         maxLines: 1,
                //         overflow: TextOverflow.ellipsis,
                //         style: TextStyle(color: Colors.white, fontSize: 15)),
                SizedBox(height: 10),
                Divider(color: Colors.white, thickness: 1),
                SizedBox(height: 10),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  DashboardScreen(pageIndex: 0)));
                    },
                    child: Text(getTranslated('shopping', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  CategoriesScreen()));
                    },
                    child: Text(getTranslated('categories', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  DashboardScreen(pageIndex: 1)));
                    },
                    child: Text(getTranslated('my_cart', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  DashboardScreen(pageIndex: 3)));
                    },
                    child: Text(getTranslated('wishlist', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      final placeOrder = Provider.of<PlaceOrderProvider>(
                          context,
                          listen: false);
                      placeOrder.runningOrderList == null ||
                              placeOrder.runningOrderList!.isEmpty
                          ? showCustomSnackBar(
                              getTranslated('no_running_orders_yet', context),
                              context)
                          : placeOrder.runningOrderList![0].deliveryMan == null
                              ? showCustomSnackBar(
                                  getTranslated('cant_track', context), context)
                              : Provider.of<OrderProvider>(context, listen: false)
                                  .addDirections(
                                      LatLng(
                                          double.parse(placeOrder
                                              .runningOrderList![0]
                                              .deliveryMan!
                                              .latitude!),
                                          double.parse(placeOrder
                                              .runningOrderList![0]
                                              .deliveryMan!
                                              .longitude!)),
                                      LatLng(
                                          double.parse(placeOrder
                                              .runningOrderList![0]
                                              .deliveryAddress!
                                              .latitude!),
                                          double.parse(placeOrder.runningOrderList![0].deliveryAddress!.longitude!)))
                                  .then((value) => Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) => OrderTrackingScreen(orderID: Provider.of<PlaceOrderProvider>(context, listen: false).runningOrderList![0].id!.toString(), track: Provider.of<PlaceOrderProvider>(context, listen: false).runningOrderList![0]))));
                    },
                    child: Text(getTranslated('track_order', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  SupportScreen()));
                    },
                    child: Text(getTranslated('help_and_support', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                TextButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  TermsScreen()));
                    },
                    child: Text(getTranslated('terms_and_condition', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500))),
                SizedBox(height: 10),
                Divider(color: Colors.white, thickness: 1),
                SizedBox(height: 10),
                TextButton(
                    onPressed: () {
                      showDialog(
                          context: context,
                          barrierDismissible: false,
                          builder: (context) => SignOutConfirmationDialog());
                    },
                    child: Text(getTranslated('logout', context),
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.w500)))
              ]));
    }));
  }
}
